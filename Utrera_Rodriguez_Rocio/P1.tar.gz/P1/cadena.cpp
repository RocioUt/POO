//
// Created by fedemeister on 09/09/18.
//


#include "cadena.hpp"
using namespace std;

/*Metodos de la clase Cadena::Cadena*/

    /*Constructores de la Cadena::Cadena*/

    Cadena::Cadena(size_t t,char relleno):s_(new char[t+1]),tam_(t){
        for(int i= 0;i<=tam_;++i)
            s_[i]=relleno;
        s_[tam_]='\0';
    }

    Cadena::Cadena(const Cadena& cad):s_(new char[cad.tam_+1]),tam_(cad.tam_){
        strcpy(s_,cad.s_);
    }

    Cadena::Cadena(const char* c):s_(new char[strlen(c)+1]),tam_(strlen(c)){
        strcpy(s_,c);
    }

Cadena::Cadena(const char* cad , size_t tam):s_(new char[tam+1]),tam_(tam){
    if( tam_>strlen(cad) ){
        tam_=strlen(cad);
        delete[] s_;
        s_ = new char[tam_+1];
        strcpy(s_,cad);
    }else{
        memcpy(s_,cad,tam_);
        s_[tam_]='\0';
    }
}

Cadena::Cadena(const Cadena& cad , size_t ini , size_t lon ){
    if(ini >= cad.length() ){throw std::out_of_range("Posición inicial de ctor. inválida");}
    if(lon==npos || ini+lon> cad.length() ){
        tam_ = cad.length()-ini;
    }else{
        tam_=lon;
    }
    s_=new char[tam_+1];
    memcpy(s_, cad.c_str()+ini, tam_);
    s_[tam_]='\0';
}

Cadena::Cadena(Cadena&& cad) noexcept:s_(cad.s_), tam_(cad.tam_){
    cad.s_=nullptr;
    cad.tam_=0;
}

/*Destructor de la clase Cadena*/


Cadena::~Cadena(){
    delete[] s_;
}

/*Operadores */
Cadena& Cadena::operator= (Cadena&& cad)noexcept
{  
    if (*this != cad) {
        delete[] s_;
        s_ = cad.s_;  
        tam_ = cad.tam_;
        cad.s_ = nullptr;  
        cad.tam_ = 0;
    }
    return *this;
}  

Cadena& Cadena::operator=(const Cadena& cad){
    if(this != &cad){
    	delete[] s_;
    	tam_=cad.tam_;
	    s_=new char[tam_+1];
    	strcpy(s_,cad.c_str());
    }
    return *this;
}

Cadena& Cadena::operator=(const char* cad){
    delete[] s_;
    s_=new char[strlen(cad)+1];
    strcpy(s_,cad);
    tam_=strlen(cad);
    return *this;
}

const char* Cadena::c_str() const{
    return s_;
}

size_t Cadena::length()const{
    return tam_;
}
Cadena& Cadena::operator +=(const Cadena& cad){
    tam_=cad.tam_+tam_;
    char* aux=new char[cad.tam_+tam_+1];
    strcpy(aux,s_);
    strcat(aux,cad.s_);
    delete[] s_;
    s_=new char[tam_+1];
    strcpy(s_,aux);
    delete[] aux;
    return (*this);
}

Cadena operator +(const Cadena& cad, const Cadena& cad2){
    Cadena aux(cad);
    return (aux+=cad2);
}

bool operator == (const Cadena& cad1,const Cadena& cad2){
    return strcmp(cad1.c_str(),cad2.c_str()) == 0;
}

bool operator != (const Cadena& cad1,const Cadena& cad2){
    return strcmp(cad1.c_str(),cad2.c_str()) != 0;
}

bool operator <  (const Cadena& cad1,const Cadena& cad2){
    return strcmp(cad1.c_str(),cad2.c_str()) <  0;
}

bool operator <= (const Cadena& cad1,const Cadena& cad2){
    return strcmp(cad1.c_str(),cad2.c_str()) <= 0;
}

bool operator >  (const Cadena& cad1,const Cadena& cad2){
    return strcmp(cad1.c_str(),cad2.c_str()) >  0;
}

bool operator >=(const Cadena& cad1,const Cadena& cad2) {
    return strcmp(cad1.c_str(),cad2.c_str()) >= 0;
}

istream& operator >>(istream& is, Cadena& cad) {
char cad_temp[32];
int i = 0;
while (is.good() && (isspace(is.get())!=0)) {
	i++;
	if (i==31) {
		cad = Cadena();
		return is;
	}
}
	is.unget();
	i=0;
	while(is.good() && !isspace(is.peek()) && i<32) {
		char x = is.get();
		if(is.good()) {
			cad_temp[i++]=x;
		}
	}
  cad_temp[i]='\0';
  cad=Cadena(cad_temp);
  return is;
}


    char& Cadena::operator[](int i){
        return s_[i];
    }
    char Cadena::operator[](int i)const{
        return s_[i];
    }
    char& Cadena::at(int i){
        if(i>=tam_ )
            throw std::out_of_range("");
        return s_[i];
    }
    char Cadena::at(int i)const{
        if(i>=tam_ )
            throw(std::out_of_range(""));
        return s_[i];
    }
    Cadena Cadena ::substr(size_t ini,int lon)const{
        if((lon+ini)>=(tam_) || lon<0 || ini>=tam_)
            throw out_of_range("");
        char* c=new char[lon+1];
        int i=0;
        while(lon>0){
            c[i]=s_[ini];
            ini++;
            i++;
            lon--;
        }
        c[i]='\0';
        Cadena aux(c);
        delete[] c;
        return aux;
    }
    ostream& operator <<(ostream& os,const Cadena& cad){
        for(int i=0;i<cad.length();++i){
            os.put(cad[i]);
        }
        return os;
    }


