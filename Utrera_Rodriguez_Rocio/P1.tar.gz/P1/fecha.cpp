//
// Created by fedemeister on 09/09/18.
//


#include "fecha.hpp"
using namespace std;


/*Constructores de la clase Fecha::Invalida*/
Fecha::Invalida::Invalida(const char* por_que): p(por_que) {}
/*Observador de la clase Fecha::Invalida*/
const char* Fecha::Invalida::por_que() const{return p;}



/*Contructores de la clase Fecha*/
Fecha::Fecha(int d,int m, int a) :dia_(d),mes_(m),anno_(a){
    time_t t_=time(0);
    tm* t=localtime(&t_);
    if(!dia_ ){ dia_=(t->tm_mday);      }
    if(!mes_ ){ mes_=(t->tm_mon+1);     }
    if(!anno_){ anno_=(t->tm_year+1900);}
    try{this->correcta();}
    catch(Fecha::Invalida i){throw;}
}

Fecha::Fecha(const char* cad){
    int d,m,a;
    try{
        if( 3 != sscanf(cad , "%d / %d /%d" , &d,&m,&a) ){
            throw Fecha::Invalida("Fecha desde cadena inválida ...");
        }
        *this = Fecha(d,m,a);//
    }catch(Fecha::Invalida e){
        throw;
    }
}

/*Métodos de la clase Fecha*/
const char* Fecha::cadena()const noexcept {
    std::setlocale(LC_TIME,"spanish_Spain");
    struct tm estructura_fecha={0,0,0,dia() , mes()-1 , anno()-1900,0,0,0};
    std::mktime(&estructura_fecha);
    static char cad[36];
    std::strftime(cad,36,"%A %d de %B de %Y", &estructura_fecha);
    return cad;
}


/*Metodos privados de la clase Fecha::Fecha*/
void Fecha::normalizar()noexcept {
    struct tm t = {0,0,0, dia_, mes_ - 1, anno_ - 1900, 0, 0, 0};
    mktime(& t);
    dia_=t.tm_mday;
    mes_=t.tm_mon+1;
    anno_=t.tm_year+1900;
}
void Fecha::correcta(){
    if((anno_<AnnoMinimo)||(anno_>AnnoMaximo))
        throw Fecha::Invalida("El año no puede ser menor de 1902 ni mayor de 2037.");
    if((mes_<1)||(mes_>12))
        throw Fecha::Invalida("Mes incorrecto");
    if(dia_<1)
        throw Fecha::Invalida("Día incorrecto");
    if(((mes_<8)&&(mes_%2))||((mes_>7)&&((mes_%2==0)))){
        if(dia_>31)
            throw Fecha::Invalida("Día incorrecto");
    }else{
        if(dia_>30){
            throw Fecha::Invalida("Día incorrecto");
        }

        if(mes_==2){
            if((anno_%4==0)&&((anno_%400==0)||(anno_%100))){
                if(dia_>29)throw Fecha::Invalida("Día incorrecto");
            }else{
                if(dia_>28)
                    throw Fecha::Invalida("Día incorrecto");
            }
        }
    }

}

/*Operadores aritmeticos que sobrecargamos*/

// Sobrecarga operador suma (Fecha + int).
Fecha Fecha::operator +(int i) const{
    Fecha f(*this);
    f.dia_=f.dia_+i;
    f.normalizar();
    try{f.correcta();}
    catch(Fecha::Invalida &in){throw;}
    return f;
}

// Sobrecarga operador pre-incremento (++Fecha).
Fecha& Fecha::operator++()  {
    try{*this=*this+1;}
    catch(Fecha::Invalida &in){throw;}
    return *this;
}

// Sobrecarga operador post-incremento (Fecha++).
Fecha Fecha::operator++(int)  {
    Fecha f(*this);
    try{*this=*this+1;}
    catch(Fecha::Invalida &in){throw;}
    return f;
}

// Sobrecarga operador pre-decremento (--Fecha).
Fecha& Fecha::operator--()  {
    try{*this=(*this)-1;}
    catch(Fecha::Invalida &in){throw;}
    return *this;
}

// Sobrecarga operador post-decremento (Fecha--).
Fecha Fecha::operator--(int)  {
    Fecha f(*this);
    try{*this=(*this)-1;}
    catch(Fecha::Invalida &in){throw;}
    return f;
}

// Sobrecarga operador resta (Fecha - int).
Fecha Fecha::operator -(int i) const {
    Fecha f(*this);
    f.dia_=f.dia_-i;
    f.normalizar();
    try{f.correcta();}
    catch(Fecha::Invalida &in){throw;}
    return f;
}

// Sobrecarga operador += .
Fecha& Fecha::operator +=(int i)  {
    try{*this=(*this)+i;}
    catch(Fecha::Invalida &in){throw;}
    return *this;
}

// Sobrecarga operador -= .
Fecha& Fecha::operator -=(int i)  {
    try{*this=(*this)-i;}
    catch(Fecha::Invalida &in){throw;}
    return *this;
}

/*Operadores logicos que sobrecargamos*/

//COMPARACIÓN DE FECHAS ==
bool operator==(const Fecha& fecha1, const Fecha& fecha2)
{
    return fecha1.dia() == fecha2.dia() && fecha1.mes() == fecha2.mes() && fecha1.anno() == fecha2.anno();
}

//COMPARACIÓN DE FECHAS <
bool operator<(const Fecha& fecha1, const Fecha& fecha2)
{
    return (fecha1 - fecha2) < 0;
}

//COMPARACIÓN DE FECHAS >
bool operator>(const Fecha& fecha1, const Fecha& fecha2)
{
    return fecha2 < fecha1;
}

//COMPARACIÓN DE FECHAS <=
bool operator<=(const Fecha& fecha1, const Fecha& fecha2)
{
    return fecha1 < fecha2 or fecha1 == fecha2;
}

//COMPARACIÓN DE FECHAS >=
bool operator>=(const Fecha& fecha1, const Fecha& fecha2)
{
    return !(fecha1 < fecha2);
}

//COMPARACIÓN DE FECHAS !=
bool operator!=(const Fecha& fecha1, const Fecha& fecha2)
{
    return !(fecha1 == fecha2);
}

//COMPARACIÓN DE FECHAS -
long operator-(const Fecha& fecha1,const Fecha& fecha2)
{
    tm fecha_1 = {};
    fecha_1.tm_mday = fecha1.dia();
    fecha_1.tm_mon = fecha1.mes() - 1;
    fecha_1.tm_year = fecha1.anno() - 1900;

    tm fecha_2 = {};
    fecha_2.tm_mday = fecha2.dia();
    fecha_2.tm_mon = fecha2.mes() - 1;
    fecha_2.tm_year = fecha2.anno() - 1900;

    auto seg = static_cast<long>(difftime(mktime(&fecha_1), mktime(&fecha_2)));
    long dias_diferencia = seg / (60*60*24);

    return dias_diferencia;
}

/*Entradas y salidas del programa*/

std::ostream& operator <<(std::ostream& os,const Fecha f){
    os <<f.cadena();
    return os;
}
std::istream& operator >>(std::istream& is, Fecha& f){
    char vec[11]="";
    is.width(11);
    try{
        is >> vec;
        f=vec;
    } catch(Fecha::Invalida&) {
        is.setstate(std::ios_base::failbit);
        throw;
    }
    return is;
}