//
// Created by fedemeister on 09/09/18.
//


#ifndef CADENA_HPP_
#define CADENA_HPP_

#include <cstring>
#include <iostream>
#include <stdexcept>

using namespace std;

class Cadena{
    public:
        static const size_t npos = static_cast<size_t>(-1);
        explicit Cadena(size_t t=0, char relleno=' ');
        Cadena(const Cadena& cad);

        Cadena(const char* c);
        Cadena(Cadena&& cad) noexcept;
        Cadena& operator=(Cadena&& cad) noexcept;

        Cadena(const char* cad , size_t tam);
        Cadena(const Cadena& cad , size_t ini , size_t lon=npos );


        ~Cadena();
        Cadena& operator =(const Cadena& cad);
        Cadena& operator =(const char* cad);
        const char* c_str()const;
        size_t length() const;
        Cadena& operator +=(const Cadena& cad);

        char operator [](int i) const;
        char& operator [](int i);
        char& at(int i) ;
        char at(int i)const ;
    	Cadena substr(size_t ini,int lon) const;

        typedef char* iterator;
        typedef const char * const_iterator;
        typedef std::reverse_iterator<iterator> reverse_iterator;
        typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

        inline iterator begin()noexcept{
            return s_;
        }

        inline iterator end()  noexcept{
            return s_+tam_;
        }

        inline const_iterator begin()  const noexcept{
            return s_;
        }

        inline const_iterator end()    const noexcept{
            return s_+tam_;
        }

        inline const_iterator cbegin() const noexcept{
            return s_;
        }

        inline const_iterator cend()   const noexcept{
            return s_+tam_;
        }

        inline reverse_iterator rbegin() noexcept{
            return reverse_iterator(end());
        }

        inline reverse_iterator rend()   noexcept{
            return reverse_iterator(begin());
        }

        inline const_reverse_iterator rbegin() const noexcept{
            return const_reverse_iterator(end());
        }

        inline const_reverse_iterator rend()   const noexcept{
            return const_reverse_iterator(begin());
        }

        inline const_reverse_iterator crbegin()const noexcept{
            return const_reverse_iterator(end());
        }

        inline const_reverse_iterator crend()  const noexcept{
            return const_reverse_iterator(begin());
        }


    private:
        char* s_; //cadena;
        size_t tam_;

};



bool operator == (const Cadena& cad1,const Cadena& cad2);

bool operator != (const Cadena& cad1,const Cadena& cad2);

bool operator <  (const Cadena& cad1,const Cadena& cad2);

bool operator <= (const Cadena& cad1,const Cadena& cad2);

bool operator >  (const Cadena& cad1,const Cadena& cad2);

bool operator >=(const Cadena& cad1,const Cadena& cad2) ;

std::ostream& operator<<(std::ostream& salida,const Cadena& cad);

std::istream& operator>>(std::istream& entrada,Cadena& cad);

Cadena operator +(const Cadena& cad,const Cadena& cad2);

namespace std { 
    template <> 
    struct hash<Cadena> {
        size_t operator() (const Cadena& cad) const
        {
            hash<string> hs;
            const char * p = cad.c_str(); 
            string s(p);
            size_t res = hs(s);
            return res;
        }
    };
}

#endif
