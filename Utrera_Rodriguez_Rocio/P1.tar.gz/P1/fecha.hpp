//
// Created by fedemeister on 09/09/18.
//


#ifndef FECHA_HPP_
#define FECHA_HPP_
#include <iostream>
#include <ctime>
#include <cstring>
#include <cstdio>


class Fecha{
    public:
        class Invalida{
            public:
                Invalida(const char* porque);
                const char* por_que() const;
            private:
                const char* p;
        };
        explicit Fecha(int d=0,int m=0,int a=0);
        Fecha(const char* c);
            int dia() const noexcept ;
            int mes() const noexcept ;
            int anno() const noexcept ;
            static const int AnnoMinimo=1902,AnnoMaximo=2037;
            const char* cadena() const noexcept;
            Fecha operator +(int i)const;
            Fecha& operator ++();
            Fecha operator ++(int n);
            Fecha operator -(int i)const;
            Fecha& operator --();
            Fecha operator --(int i);
            Fecha& operator +=(int i);
            Fecha& operator -=(int i);
    private:
        int convertir(char c);
        void normalizar() noexcept;
        void correcta();
        int dia_ ,mes_ ,anno_;
};

inline int Fecha::convertir(char c){return (int)(c-'0');}


/*Observadores de la clase Fecha::Fecha*/
inline int Fecha::dia() const noexcept {return dia_;}
inline int Fecha::mes() const noexcept {return mes_;}
inline int Fecha:: anno() const noexcept {return anno_;}

bool operator ==(const Fecha& a,const Fecha& f);
bool operator !=(const Fecha& a,const Fecha& f);
bool operator <(const Fecha& a,const Fecha& f);
bool operator >(const Fecha& a,const Fecha& f);
bool operator <=(const Fecha& a,const Fecha& f);
bool operator >=(const Fecha& a,const Fecha& f);

long operator - (const Fecha& f1 ,const Fecha& f2);

std::ostream& operator <<(std::ostream& os, Fecha f);
std::istream& operator >>(std::istream& is, Fecha& f);

#endif
